#ifndef AUTOTHREAD_H
#define AUTOTHREAD_H
#include <QThread>

class AutoThread :public QThread
{
    Q_OBJECT
public:
    AutoThread();

protected:
    void run();

signals:
    create_random_PCB_signal();
    ask_for_next_signal();
};

#endif // AUTOTHREAD_H
