#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <cmath>
#include <ctime>
#include <QThread>
#include <QDebug>
#include <algorithm>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("进程调度");
    srand((unsigned)time(0));

    //初始化未分分区表
    Partition* partition = new Partition;

    partition->PID   = "";
    partition->front = nullptr;
    partition->next  = nullptr;
    partition->size  = MAXPARTITIONSIZE-20;
    partition->state = 0;
    partition->address = 20;//系统内存为20
    Partition_Queue.append(partition);
    print_Partition_Queue();


    autothread = new AutoThread();

    connect(this,SIGNAL(PCB_in_CPU_finished()),this,SLOT(deal_PCB_in_CPU_finished()));
    connect(this,SIGNAL(PCB_state_changed_from_job_to_ready()),this,SLOT(deal_PCB_state_changed_from_job_to_ready()));
    connect(autothread,SIGNAL(create_random_PCB_signal()),this,SLOT(deal_create_random_PCB_signal()));
    connect(autothread,SIGNAL(ask_for_next_signal()),this,SLOT(on_Time_next_Button_clicked()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Schdule_add_button_clicked()
{
    //创建一个PCB
    PCB* tmpPCB = new PCB;
    //将输入的信息赋给新建的PCB
    tmpPCB->PID = ui->SATF_name->toPlainText();
    tmpPCB->time = atoi(ui->SATF_time->toPlainText().toStdString().c_str());//QString转int
    tmpPCB->priority = atoi(ui->SATF_priority->toPlainText().toStdString().c_str());
    tmpPCB->requiredMemory = atoi(ui->SATF_requiredAddress->toPlainText().toStdString().c_str());
    tmpPCB->statement = "candidate";
    //使上一个后备队列的PCB指向新建的PCB
    if(PCB_Job_Queue.size()!=0)
    {
        PCB_Job_Queue.at(PCB_Job_Queue.size()-1)->next = tmpPCB;
    }
    //将新建的PCB加入队列
    PCB_Job_Queue.append(tmpPCB);
    emit PCB_state_changed_from_job_to_ready();
}

void MainWindow::print_PCB_Job_Queue(int k)
{
    for(int i=0;i<PCB_Job_Queue.size();i++)
    {
        if(k==1)      ui->QueueTF_job_name->insertPlainText(PCB_Job_Queue[i]->PID+'\n');
        else if(k==2) ui->QueueTF_job_time->insertPlainText(QString::number(PCB_Job_Queue[i]->time)+'\n');
        else          ui->QueueTF_job_priority->insertPlainText(QString::number(PCB_Job_Queue[i]->priority)+'\n');
    }
}

void MainWindow::print_PCB_Ready_Queue(int k){
    for(int i=0;i<PCB_Ready_Queue.size();i++)
    {
        if(k==1)      ui->QueueTF_ready_name->insertPlainText(PCB_Ready_Queue[i]->PID+'\n');
        else if(k==2) ui->QueueTF_ready_time->insertPlainText(QString::number(PCB_Ready_Queue[i]->time)+'\n');
        else if(k==3)         ui->QueueTF_ready_priority->insertPlainText(QString::number(PCB_Ready_Queue[i]->priority)+'\n');
        else          ui->QueueTF_ready_size->insertPlainText(QString::number(PCB_Ready_Queue[i]->requiredMemory)+'\n');
    }
}

void MainWindow::print_PCB_Pending_Queue(int k)
{
    for(int i=0;i<PCB_pended_Queue.size();i++)
    {
        if(k==1)      ui->QueueTF_pending_name->insertPlainText(PCB_pended_Queue[i]->PID+'\n');
        else if(k==2) ui->QueueTF_pending_time->insertPlainText(QString::number(PCB_pended_Queue[i]->time)+'\n');
        else          ui->QueueTF_pending_priority->insertPlainText(QString::number(PCB_pended_Queue[i]->priority)+'\n');
    }
}

void MainWindow::print_Partition_Queue()
{
    ui->Partition_address->clear();
    ui->Partition_size->clear();
    ui->Partition_state->clear();
    ui->Partition_id->clear();
    for(int i=0;i<Partition_Queue.size();i++)
    {
        ui->Partition_address->insertPlainText(QString::number(Partition_Queue[i]->address)+'\n');
        ui->Partition_size->insertPlainText(QString::number(Partition_Queue[i]->size)+'\n');
        ui->Partition_state->insertPlainText(QString::number(Partition_Queue[i]->state)+'\n');
        ui->Partition_id->insertPlainText(Partition_Queue[i]->PID+'\n');
    }
}

void MainWindow::on_Schedule_clear_button_clicked()
{
    ui->SATF_name->clear();
    ui->SATF_time->clear();
    ui->SATF_priority->clear();
    ui->SATF_requiredAddress->clear();
}

void MainWindow::deal_PCB_in_CPU_finished()
{
    emit PCB_state_changed_from_job_to_ready();
}

void MainWindow::on_Time_next_Button_clicked()
{
    //每进行一个时间单元
    emit PCB_state_changed_from_job_to_ready();
    //判断目前的调度算法
    if(Scheduling_algorithm == "优先权调度")
    {
        //获取就绪队列中优先级最大的PCB下标（若有重复则选择下标最小的，并储存在index中)
        if(PCB_Ready_Queue.size()>0)
        {
            int index = 0;
            int MaxPriority = -1;
            if(PCB_Ready_Queue[0]->statement!="pended")
            {
                MaxPriority = PCB_Ready_Queue[0]->priority;
            }
            for(int i =1;i<PCB_Ready_Queue.size();i++)
            {
                if(PCB_Ready_Queue[i]->priority>MaxPriority&&PCB_Ready_Queue[i]->statement!="pended")
                {
                    index = i;
                    MaxPriority = PCB_Ready_Queue[i]->priority;
                }
            }
            //将就绪队列中下标为index的PCB送入CPU中处理
            PCB_in_CPU = PCB_Ready_Queue.takeAt(index);
        }
        //CPU中PCB时间-1，优先权-1，如果剩余时间为0则进程完成,并发送信号，否则将其又送回就绪队列中
        if(PCB_in_CPU!=nullptr)
        {
            PCB_in_CPU->time--;
            if(PCB_in_CPU->priority>1)
            {
                PCB_in_CPU->priority--;
            }
            if(PCB_in_CPU->time<=0)
            {
                for(int i=0;i<Partition_Queue.size();i++)
                {
                    if(Partition_Queue[i]->address==PCB_in_CPU->MemoryAddress)
                    {
                        Partition_Queue[i]->state = 0;
                        Partition_Queue[i]->PID   = "";
                        //合并分区 注意内存始址越大的Partition的下标越小
                        if(i>0&&Partition_Queue[i-1]->state==0)
                        {
                            Partition_Queue[i]->size+=Partition_Queue[i-1]->size;
                            Partition_Queue.takeAt(i-1);
                            i-=1;
                        }
                        if(i<Partition_Queue.size()-1&&Partition_Queue[i+1]->state==0)
                        {
                            Partition_Queue[i+1]->size+=Partition_Queue[i]->size;
                            Partition_Queue.takeAt(i);
                        }
                        break;
                    }
                }
                emit PCB_in_CPU_finished();
//                PCB_in_CPU = nullptr;
            }
            else
            {
                PCB_Ready_Queue.append(PCB_in_CPU);
            }
        }
    }
    else
    {
        PCB_in_CPU = PCB_Ready_Queue.takeAt(0);
        //CPU中PCB时间-1，优先权-1，如果剩余时间为0则进程完成,并发送信号，否则将其又送回就绪队列中
        if(PCB_in_CPU!=nullptr)
        {
            PCB_in_CPU->time--;
            if(PCB_in_CPU->priority>1)
            {
                PCB_in_CPU->priority--;
            }
            if(PCB_in_CPU->time<=0)
            {
                for(int i=0;i<Partition_Queue.size();i++)
                {
                    if(Partition_Queue[i]->address==PCB_in_CPU->MemoryAddress)
                    {
                        Partition_Queue[i]->state = 0;
                        Partition_Queue[i]->PID   = "";
                        //合并分区 注意内存始址越大的Partition的下标越小
                        if(i>0&&Partition_Queue[i-1]->state==0)
                        {
                            Partition_Queue[i]->size+=Partition_Queue[i-1]->size;
                            Partition_Queue.takeAt(i-1);
                            i-=1;
                        }
                        if(i<Partition_Queue.size()-1&&Partition_Queue[i+1]->state==0)
                        {
                            Partition_Queue[i+1]->size+=Partition_Queue[i]->size;
                            Partition_Queue.takeAt(i);
                        }
                        break;
                    }
                }
                emit PCB_in_CPU_finished();
//                PCB_in_CPU = nullptr;
            }
            else
            {
                PCB_Ready_Queue.append(PCB_in_CPU);
            }
        }
    }

    //刷新后备队列的信息
    ui->QueueTF_job_name->clear();
    ui->QueueTF_job_time->clear();
    ui->QueueTF_job_priority->clear();
    print_PCB_Job_Queue(1);
    print_PCB_Job_Queue(2);
    print_PCB_Job_Queue(3);
    //刷新就绪队列的信息
    ui->QueueTF_ready_name->clear();
    ui->QueueTF_ready_time->clear();
    ui->QueueTF_ready_priority->clear();
    ui->QueueTF_ready_size->clear();
    print_PCB_Ready_Queue(1);
    print_PCB_Ready_Queue(2);
    print_PCB_Ready_Queue(3);
    print_PCB_Ready_Queue(4);
    //刷新CPU信息
//    if(PCB_in_CPU!=nullptr)
//    {
    ui->CPUTF_name->setText(PCB_in_CPU->PID);
    ui->CPUTF_time->setText(QString::number(PCB_in_CPU->time));
    ui->CPUTF_priority->setText(QString::number(PCB_in_CPU->priority));
//    }
    //刷新分区队列信息
    print_Partition_Queue();
}

void MainWindow::on_channel_spinBox_editingFinished()
{
    channel = atoi(ui->channel_spinBox->text().toStdString().c_str());
}

void MainWindow::deal_create_random_PCB_signal()
{
    //创建一个PCB
    PCB* tmpPCB = new PCB;
    //将PCB赋予随机值
    tmpPCB->PID = "plnb"+QString::number(rand()%100);
    tmpPCB->time = rand()%5+1;
    tmpPCB->priority = rand()%50+50;
    tmpPCB->statement = "candidate";
    tmpPCB->MemoryAddress = -1;
    tmpPCB->requiredMemory = rand()%21+15;
    //使上一个后备队列的PCB指向新建的PCB
    if(PCB_Job_Queue.size()!=0)
    {
        PCB_Job_Queue.at(PCB_Job_Queue.size()-1)->next = tmpPCB;
    }
    //将新建的PCB加入队列
    PCB_Job_Queue.append(tmpPCB);
    emit PCB_state_changed_from_job_to_ready();
}

void MainWindow::on_Time_Auto_Button_clicked()
{
    autothread->start();
}

void MainWindow::on_Schdule_random_add_button_clicked()
{
    //创建一个PCB
    PCB* tmpPCB = new PCB;
    //将随机信息赋给新建的PCB
    tmpPCB->PID = "plnb"+QString::number(rand()%100);
    tmpPCB->time = rand()%5+1;
    tmpPCB->priority = rand()%50+50;
    tmpPCB->statement = "candidate";
    tmpPCB->MemoryAddress = -1;
    tmpPCB->requiredMemory = rand()%21+10;
    //使上一个后备队列的PCB指向新建的PCB
    if(PCB_Job_Queue.size()!=0)
    {
        PCB_Job_Queue.at(PCB_Job_Queue.size()-1)->next = tmpPCB;
    }
    //将新建的PCB加入队列
    PCB_Job_Queue.append(tmpPCB);
    //由于接下来的操作和CPU完成了一个进程后的操作相同（处理将后备队列里符合条件的PCB给就绪队列），直接发信号
    emit PCB_state_changed_from_job_to_ready();
}

void MainWindow::on_pend_Button_clicked()
{
    int index = atoi(ui->pending_spinBox->text().toStdString().c_str())-1;
    PCB_Ready_Queue[index]->statement = "pended";
    PCB_pended_Queue.append(PCB_Ready_Queue[index]);
    //刷新挂起队列信息
    ui->QueueTF_pending_name->clear();
    ui->QueueTF_pending_time->clear();
    ui->QueueTF_pending_priority->clear();
    print_PCB_Pending_Queue(1);
    print_PCB_Pending_Queue(2);
    print_PCB_Pending_Queue(3);

}

void MainWindow::on_DisPend_Button_clicked()
{
    int index = atoi(ui->DisPend_spinBox->text().toStdString().c_str())-1;
    PCB_pended_Queue[index]->statement = "ready";
    PCB_pended_Queue.takeAt(index);
    //刷新挂起队列信息
    ui->QueueTF_pending_name->clear();
    ui->QueueTF_pending_time->clear();
    ui->QueueTF_pending_priority->clear();
    print_PCB_Pending_Queue(1);
    print_PCB_Pending_Queue(2);\
    print_PCB_Pending_Queue(3);
}

void MainWindow::on_comboBox_activated(const QString &arg1)
{
    Scheduling_algorithm = ui->comboBox->currentText();
    qDebug()<<Scheduling_algorithm;
}

void MainWindow::deal_PCB_state_changed_from_job_to_ready()
{
    if(PCB_Ready_Queue.size()<channel&&PCB_Job_Queue.size()>0)
    {
        //判断目前的调度算法
        if(Scheduling_algorithm == "优先权调度")
        {
            //用一个队列临时储存放不进的PCB
            QList<PCB*> PCB_tmp_Queue;
            //不断获取优先级最大的PCB下标，PCB能放进内存就终止循环，放不进内存就把这个PCB扔到临时队列中
            while(PCB_Job_Queue.size()>0)
            {
                //获取后备队列中优先级最大的PCB下标（若有重复则选择下标最小的，并储存在index中)
                int index = 0;
                int MaxPriority = PCB_Job_Queue[0]->priority;
                for(int i =1;i<PCB_Job_Queue.size();i++)
                {
                    if(PCB_Job_Queue[i]->priority>MaxPriority)
                    {
                        index = i;
                        MaxPriority = PCB_Job_Queue[i]->priority;
                    }
                }
                PCB* tmpPCB = PCB_Job_Queue.takeAt(index);

                //寻找未分分区表中的最先适应的空闲分区
                for(int i=0;i<Partition_Queue.size();i++)
                {
                    if(tmpPCB->requiredMemory<Partition_Queue[i]->size&&Partition_Queue[i]->state==0)
                    {
                        Partition* partition = new Partition();
                        partition->address = Partition_Queue[i]->address+tmpPCB->requiredMemory;
                        //由于qlist比较特殊，下面有些代码可以不写
//                        partition->front   = Partition_Queue[i];
//                        partition->next    = Partition_Queue[i]->next;
                        partition->size    = Partition_Queue[i]->size-tmpPCB->requiredMemory;
                        partition->state   = 0;
                        Partition_Queue[i]->PID     = tmpPCB->PID;
//                        Partition_Queue[i]->next  = partition;
                        Partition_Queue[i]->state = 1;
                        Partition_Queue[i]->size  = tmpPCB->requiredMemory;
                        tmpPCB->statement     = "就绪";
                        tmpPCB->MemoryAddress = Partition_Queue[i]->address;
//                        Partition_Queue.append(partition);
                        //在第i个元素后面插入partition
                        Partition_Queue.insert(i,partition);
                        print_Partition_Queue();
                        break;
                    }

                }
                //如果for循环里的if语句一次都没有执行，那么tmpPCB的内存地址还是-1
                if(tmpPCB->MemoryAddress>=0)
                {
                    //把后备队列中下标为index的PCB拿出来放到就绪队列里
                    PCB_Ready_Queue.append(tmpPCB);
                    break;
                }
                else
                {
                    PCB_tmp_Queue.append(tmpPCB);
                }

            }
            //将临时PCB队列里的PCB还给后备队列
            while (PCB_tmp_Queue.size()>0) {
                PCB_Job_Queue.append(PCB_tmp_Queue.takeAt(0));
            }

        }
        else
        {
            //用一个队列临时储存放不进的PCB
            QList<PCB*> PCB_tmp_Queue;
            //不断获取优先级最大的PCB下标，PCB能放进内存就终止循环，放不进内存就把这个PCB扔到临时队列中
            for(int index=0;index<PCB_Job_Queue.size();index++)
            {
                PCB* tmpPCB = PCB_Job_Queue.takeAt(index);

                //寻找未分分区表中的最先适应的空闲分区
                for(int i=0;i<Partition_Queue.size();i++)
                {
                    if(tmpPCB->requiredMemory<Partition_Queue[i]->size&&Partition_Queue[i]->state==0)
                    {
                        Partition* partition = new Partition();
                        partition->address = Partition_Queue[i]->address+tmpPCB->requiredMemory;
                        //由于qlist比较特殊，下面有些代码可以不写
//                        partition->front   = Partition_Queue[i];
//                        partition->next    = Partition_Queue[i]->next;
                        partition->size    = Partition_Queue[i]->size-tmpPCB->requiredMemory;
                        partition->state   = 0;
                        Partition_Queue[i]->PID     = tmpPCB->PID;
//                        Partition_Queue[i]->next  = partition;
                        Partition_Queue[i]->state = 1;
                        Partition_Queue[i]->size  = tmpPCB->requiredMemory;
                        tmpPCB->statement     = "就绪";
                        tmpPCB->MemoryAddress = Partition_Queue[i]->address;
//                        Partition_Queue.append(partition);
                        //在第i个元素后面插入partition
                        Partition_Queue.insert(i,partition);
                        print_Partition_Queue();
                        break;
                    }

                }
                //如果for循环里的if语句一次都没有执行，那么tmpPCB的内存地址还是-1
                if(tmpPCB->MemoryAddress>=0)
                {
                    //把后备队列中下标为index的PCB拿出来放到就绪队列里
                    PCB_Ready_Queue.append(tmpPCB);
                    break;
                }
                else
                {
                    PCB_tmp_Queue.append(tmpPCB);
                }

            }
            //将临时PCB队列里的PCB还给后备队列
            while (PCB_tmp_Queue.size()>0) {
                PCB_Job_Queue.append(PCB_tmp_Queue.takeAt(0));
            }
        }
    }
    //刷新后备队列的信息
    ui->QueueTF_job_name->clear();
    ui->QueueTF_job_time->clear();
    ui->QueueTF_job_priority->clear();
    print_PCB_Job_Queue(1);
    print_PCB_Job_Queue(2);
    print_PCB_Job_Queue(3);
    //刷新就绪队列的信息
    ui->QueueTF_ready_name->clear();
    ui->QueueTF_ready_time->clear();
    ui->QueueTF_ready_priority->clear();
    ui->QueueTF_ready_size->clear();
    print_PCB_Ready_Queue(1);
    print_PCB_Ready_Queue(2);
    print_PCB_Ready_Queue(3);
    print_PCB_Ready_Queue(4);
    //刷新分区队列信息
    print_Partition_Queue();
}
