#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include "autothread.h"

namespace Ui {
class MainWindow;
}

struct PCB{
    QString PID;
    int time;
    int priority;
    QString statement;
    PCB* next;
    int requiredMemory = -1;
    int MemoryAddress  = -1;
};

struct Partition{
    QString PID;//进程
    Partition* front;//前向指针
    Partition* next;//后向指针
    int address;//起始地址
    int state;//状态位，0表示未分配，1表示已分配（空表目）
    int size;//分区大小
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    QList<PCB*> PCB_Job_Queue;//后备队列
    QList<PCB*> PCB_Ready_Queue;//就绪队列
    QList<PCB*> PCB_pended_Queue;//挂起队列
    QList<Partition*> Partition_Queue;//空闲分区链

    void print_PCB_Job_Queue(int k);//k值1,2,3分别代表id，time和priority
    void print_PCB_Ready_Queue(int k);//k值1,2,3分别代表id，time和priority
    void print_PCB_Pending_Queue(int k);//k值1,2,3分别代表id，time和priority
    void print_Partition_Queue();
    PCB* PCB_in_CPU;//储存CPU中的PCB

    const int MAXPARTITIONSIZE = 100;//预设主存大小为100
    int channel = 4;//储存道数
    AutoThread* autothread;//定时器进程
    QString Scheduling_algorithm = "优先权调度";//调度算法


private slots:
    void on_Schdule_add_button_clicked();

    void on_Schedule_clear_button_clicked();

    void deal_PCB_in_CPU_finished();

    void on_Time_next_Button_clicked();

    void on_channel_spinBox_editingFinished();
    void deal_create_random_PCB_signal();

    void on_Time_Auto_Button_clicked();

    void on_Schdule_random_add_button_clicked();

    void on_pend_Button_clicked();

    void on_DisPend_Button_clicked();

    void on_comboBox_activated(const QString &arg1);

    void deal_PCB_state_changed_from_job_to_ready();



signals:
    void PCB_in_CPU_finished();
    void PCB_state_changed_from_job_to_ready();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
