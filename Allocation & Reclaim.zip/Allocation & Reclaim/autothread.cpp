#include "autothread.h"

AutoThread::AutoThread()
{

}

void AutoThread::run()
{
    //每隔一段时间创建一个随机的PCB
    while(true)
    {
        emit create_random_PCB_signal();
        msleep(250);
        emit ask_for_next_signal();
        msleep(250);
        emit ask_for_next_signal();
//        msleep(250);
//        emit ask_for_next_signal();
    }
}
